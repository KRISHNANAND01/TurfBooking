﻿namespace TurfBooking.DTO
{
    public class UserDTO
    {
    }
}
