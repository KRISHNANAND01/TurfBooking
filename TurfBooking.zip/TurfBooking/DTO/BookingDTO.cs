﻿namespace TurfBooking.DTO
{
    public class BookingDTO
    {
    }
}
